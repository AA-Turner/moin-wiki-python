
from fs.s3fs import S3FS
from fs.expose import fuse
from fs.wrapfs import WrapFS

from filelike.wrappers import FileWrapper, UnBZip2

#  Simple "encryption" using rot13.  Unfortunately complicated by the
#  fact that the native rot13 encoding can't handle non-ascii bytes:
#
#      >>> "hi there".encode("rot13")
#      'uv gurer'
#      >>> "hi there \x80".encode("rot13")
#      Traceback (most recent call last):
#        File "<stdin>", line 1, in <module>
#        File "/usr/lib/python2.6/encodings/rot_13.py", line 17, in encode
#          return codecs.charmap_encode(input,errors,encoding_map)
#      UnicodeDecodeError: 'ascii' codec can't decode byte 0x80 in position 9: ordinal not in range(128)
#
rot13 = lambda c: c.encode("rot13") if ord(c) < 127 else c
encrypt = decrypt = lambda d: "".join(rot13(c) for c in d)


#  A custom file-like object wrapper.
#  The _read(size) method should read approximately 'size' bytes from the
#  underlying file and return None at EOF.  The _write(data) method should
#  write as much of 'data' as possible to the underlying file, and return
#  any data that could not be written.  Internal buffering logic then 
#  constucts a fully-fledged filelike object with read(), iter(), etc.
#
#  We decrypt data being read from the file, and encrypt data being written.
#  Because rot13 encodes data byte-by-byte, we don't need to provide a special
#  implementation for seek() and tell().
#
#  In reality, you would use a Cipher object from PyCrypto and the pre-built
#  Decrypt wrapper from filelike.wrappers.
class Decrypt(FileWrapper):

    def _read(self,size=-1):
        return decrypt(self._fileobj.read(size)) or None

    def _write(self,data,flushing=False):
        self._fileobj.write(encrypt(data))


#  We extend the filesystem wrapper to apply both encryption and compression.
#  This encrypts both file contents and path names, using some hooks provided
#  by the WrapFS base class to avoid a heap of boilerplate.
class EncZipFS(WrapFS):

    def _file_wrap(self,file,mode):
        return UnBZip2(Decrypt(file))

    def _encode(self,path):
        return encrypt(path)

    def _decode(self,path):
        return decrypt(path)


#  Apply the wrapper and mount into the filesystem as before.
#  Again, the use of foreground=True is required to avoid pickling the
#  'myfiles' object; this limitation will go away in a future release.
myfiles = EncZipFS(S3FS("myfiles-enczip"))
fuse.mount(myfiles,".mnt/myfiles-enczip",foreground=True)

