
from fs.s3fs import S3FS
from fs.expose import fuse
from fs.wrapfs import WrapFS

#  UnBZip2 is similar to the stdlib bz2.BZ2File but can
#  wrap an existing file-like object.
from filelike.wrappers.compress import UnBZip2

#  This is a filesystem wrapper class.  By default it forwards
#  all operations directly to self.wrapped_fs.  We override the
#  open() method to apply the UnBZip2 wrapper and transparently
#  decompress files from the wrapped FS.
class ZipFS(WrapFS):
    def open(self,path,mode):
        return UnBZip2(self.wrapped_fs.open(path,mode))


#  Apply the compression wrapper to the files from S3.
myfiles = ZipFS(S3FS("myfiles-zip"))

#  Mount into the filesystem as before.
#  Without foreground=True, this will spawn a background process to
#   manage the mount point.  The current implementation passes 'myfiles'
#  to the background process by pickling, which won't work in this case
#  since you can't pickle classes defined in the __main__ module.
#  This limitation will go away in a future release.
fuse.mount(myfiles,".mnt/myfiles-zip",foreground=True)


