
from fs.s3fs import S3FS
from fs.expose import fuse

#  Access an Amazon S3 bucket as a filesystem object.  You'll need
#  to specify your AWS credentials in the envionment variables
#  AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.
myfiles = S3FS("my.unique.bucket.name")

#  Mount the filesystem object using FUSE.  The specified mount point
#  must already exist.  Without foreground=True this will spawn a
#  background process, which unfortunately won't work correctly for
#  the later examples :-(
fuse.mount(myfiles,".mnt/myfiles",foreground=True)

