sudo aptitude install python-setuptools
sudo easy_install pip
sudo pip install sphinx
./build_progguide.bash

Print these landscape, double-sided, on 8.5 x 11 inch paper,
in page order 
20,1,2,19,18,3,4,17,16,5,6,15,14,7,8,13,12,9,10,11
(formula for booklet-style page orders is at
http://www.linux.com/archive/articles/139752)

- catherine.devlin@gmail.com
