
.. image:: pyohio-green.jpg

===========
PyOhio 2010
===========

You are Python
==============

Python is not just a language - it’s a community of people sharing code, ideas, knowledge, excitement, and energy to make something we all benefit from and enjoy. PyOhio is not just a series of talks, but a chance to plunge deep into the Python community. Prepare yourself not just to receive information, but to ask questions, answer questions, have great conversations, try things out, and work together.

You are PyOhio
==============

We know, it's tempting to spend the whole weekend going from one talk to the next - we have a great talk lineup. Remember, though, that we're also here for the conversations and encounters that can only happen in person; and, since our talks are being recorded for publication at python.mirocommunity.org, you don't need to worry that you'll miss talk content forever if you make another choice. Try the Sprints, and check the Open Space boards *frequently*!

.. raw:: pdf

   PageBreak

..

Notes
=====

.. raw:: pdf

   PageBreak

Map
===

.. image:: oufloorplans.png
   :height: 2in

Main PyOhio events take place in the northwest corner of the 3rd floor of the
Ohio Union.  Monday and Tuesday daytime sprints take place in the Creative Arts
room in the OU's Lower Level.

.. image:: tosprints.png
   :height: 1.5in

To get to evening sprints, exit the OU onto High Street (you're facing Bento Go Go),
turn left, and walk north on High Street until Arps Hall is on your left.

Food
====

PyOhio isn't providing lunch, but there are plenty of options on the first floor of the Ohio Union and out the door on High Street. DON'T EAT ALONE! Remember, the character who goes off alone always gets eaten by zombies. We're all here to be with other Python lovers, so invite lunch companions fearlessly, especially if you spot somebody with a PyOhio badge and no apparent lunch companions.

If you'd like to join an impromptu group for a trip to a specific restaurant, look for the "Gather here for:" signs on the easels outside the PyOhio talk and open-space rooms.

Lightning Talks
===============

Saturday and Sunday each end with the Lightning Talks, a rapid-fire succession of five-minute presentations on any topic (serious or not) that you'd like to bring to the Python community. We'll also use the Lightning Talks to distribute swag prizes... must be present to win! If you'd like to give a Lightning Talk, just sign up at the registration desk.


Open Spaces
===========

Two Open Space rooms (Ailabouni and Rutner) are set aside for attendees to create 
their own conference content on the fly.  Check the Open Space board *frequently* to
find out what's going on.

What can you do with Open Spaces?
---------------------------------

 * Informal, unplanned discussions on a topic
 * Cooperative workshops
 * Teach-Me learner-driven classes
 * Regular-style talks
 * Follow-up discussions after scheduled talks
 * Something just for fun (board game, card game, sing-a-long...)
 * Anything else you can think of...

How do I schedule an Open Space?
--------------------------------

Anybody can schedule an Open Space; you don't need anybody's approval.
Look for the Open Space board on an easel near the registration desk.
Choose an open spot on the grid representing a time slot and room.
Take one of the provided index cards, write down a topic and your name, 
and stick it to the board. Show up and see what happens!

Sounds crazy. Does that actually work?
--------------------------------------

It does! People who’ve tried it generally come quickly to love it. In any case, the Law of Two Feet means that you can try an Open Space event for precisely as long as you are benefiting from it — if you aren’t, then you are not just allowed but *obligated* to leave. There’s no reason not to try it!

Sprints
=======

Sprints are cooperative workshops where we work together on open-source projects. Sprinters can write new code or documentation, or fix bugs in either. All skill levels can sprint - in fact, working alongside more experienced Pythonistas can be a great way to improve your skills. All PyOhio attendees are invited to the sprints; just show up and introduce yourself. Groups will be sprinting on these topics:

 * Python core
 * Android Scripting Environment
 * Django
 * Flask
 * Pyjamas

On Saturday and Sunday, sprinters will work from 7 PM to midnight at Subway at 1739 North High Street. (This is the large Subway restaurant fronting directly on High Street a few blocks north of the Ohio Union, *not* the small one on East 13th Ave.) Any sprinters surviving when Subway closes at midnight can move to Buckeye Donuts at 1998 North High Street.

On Monday and Tuesday, sprinters will work from 9 AM to 7 PM in the Creative Arts room in the basement level of the Ohio Union; after 7 PM, they will move to the Subway.

.. raw:: pdf

   PageBreak

Local Groups
============

	Ann Arbor: Michipug
	  http://groups.google.com/group/michipug
	Cincinnati: CincyPy
	  http://groups.google.com/group/cincypy
	Cleveland: ClePy
	  http://www.clepy.org/
	Columbus: Central Ohio Python Users Group
	  http://www.meetup.com/Central-Ohio-Python-Users-Group/
	Columbus: OSU Open Source Club
          http://opensource.cse.ohio-state.edu/
	Dayton: Dynamic Languages Users Group
          http://www.dma.org/sigs.shtml#Dynamic          
        Grand Rapids: Grand Rapids Python Users Group
          http://www.grpug.org/
	Indianapolis: IndyPy
	  http://python.meetup.com/182


Other Events
============

 * Sep. 2010: Ohio LinuxFest, Columbus
 * Oct. 2010: Central PA Open Source Conference, Harrisburg
 * Jan. 2011: CodeMash, Sandusky
 * Mar. 2011: PenguiCon, Detroit
 * Mar. 2011: PyCon, Atlanta
 * GiveCamps in Ann Arbor (September), Miami U. (October), Cleveland (July), Columbus (July)...
 * columbustechevents.com, clevelandtechevents.com, daytontechevents.com

.. raw:: pdf

   PageBreak

Staff
=====

     Chair
       Catherine Devlin
     Vice-Chair
       Eric Floehr
     Program Committee
       David Stanek, Alex Gaynor, Chris Miller, Mat Kovach, Jay Shaffstall, Mike Crute, Doug Stanley
     A/V
       Carl Karsten, Ryan Verner, Jen Leadbetter
     Session chairs
       Matt Arnold, Benjamin Smith, Scott Scites, Sarah Dutkiewicz, Heidi Hooper, Theodore Turocy
     Facility Liason
       John Langkals
     Publicity Chair
       Sarah Dutkiewicz
     Open-space Coordinator
       Scott McCarty
     Webmaster
       David Stanek
     Sprint coordinator
       Nicholas Bastin

Social Networking
=================

  * http://www.linkedin.com/groups?gid=1895625
  * Twitter: @pyohio and #pyohio
  * http://www.facebook.com/group.php?gid=333853895634
  * Chat: http://www.meebo.com/room/pyohio/ 
  * #pyohio on http://webchat.freenode.net/

Garter Snake Sponsor: DMA
=========================

The **Dayton Microcomputer Association** (http://dma.org/) is one of the country's oldest
and most diverse computer users' groups.  The DMA meets on the last
Tuesday of each month at 7 PM.

The DMA includes many 
Special Interest Groups (SIGs), including the Dayton Dynamic Languages
User Group, which meets the second Wednesday of each month at 7 PM at
the Dayton Chess Club.

Venue Sponsor
=============

.. image:: open_source_banner_2.png

The Open Source Club at Ohio State University
focuses on building a strong community of open source users and developers in order to bring the benefits of open development, open standards, and free software to the university community, and beyond.
OSC is open to all, including non-students.  It 
meets every Thursday during the school year 
at 7p in Dreese Labs 305.

http://opensource.cse.ohio-state.edu/

Swag providers
==============

.. image:: swagsponsors.png

.. raw:: pdf
 
   PageBreak

Thanks to
=========

We wanted a high-quality Python conference without charge
to attendees, so we planned an extensive scheme of identity theft and credit card fraud.

Fortunately, we were saved from a life of crime by the generosity of our sponsors:

 * Microsoft
 * Intellovations
 * AG Interactive
 * Dayton Microcomputer Association
 
The Ohio State University's Open Source Club supplies volunteer labor and
campus knowledge, and makes the Ohio Union facilities available to us at 
extremely low student-group rates.

Lyndsey Greer of the Ohio Union has been very helpful and responsive to our venue needs.

YAPC::NA::2010 staff supplied site advice, swag, and speakers' parking passes.

The Python Software foundation provided seed money for the first PyOhio, 
continues to provide an expert A/V crew, and acts as PyOhio's parent
organization for legal and financial purposes (sparing us the expense and
labor of incorporating PyOhio itself).  If you'd like to thank the PSF
and help them seed more regional conferences like PyOhio, there's a 
donation bucket at the registration desk.
 
PyOhio is run entirely by volunteers.  The main channel for communication
between volunteers is the pyohio-organizers@python.org mailing list - we'd 
love to have you join the list to provide feedback from this year and to 
find out how you can help next year.

Finally, thanks to YOU for coming and participating.  Tell your friends -
we'd love to see them at PyOhio 2011!

.. raw:: pdf
 
   PageBreak

Anaconda Sponsor
================

.. image:: filler.png
   :height: 15pc

.. image:: mslogo-1.tif
   :width: 100pc

.. raw:: pdf
 
   PageBreak

Rattlesnake Sponsor
===================

.. image:: filler.png
   :height: 3pc

.. image:: intellovations.tif

.. image:: filler.png
   :height: 5pc

Rattlesnake Sponsor
===================

.. image:: filler.png
   :height: 3pc

.. image:: AGI_logo.png

.. raw:: pdf
 
   PageBreak

Talk Descriptions
=================

Saturday, 10 AM
---------------

ROUND ROOM: *Project
Management 101* (James
Bonanno) - Python is employed
for a general purpose project
management tool. Contrasted to
tools like Sphinx which focus
on documenting a software
project, this framework is
intended for general purpose
project management, with a
specific application into
engineering projects.
Intermediate uses of Python are
employed, as well as the
Web.py framework, Sphinx
documentation tool and the
Mako template system. The
author has used this tool to
create internal commercial
applications of the project
management software.  *Audience: intermediate*

CARTOON 1: *Micro-
optimization strategies for
Python* (Nick Bastin) - As
opposed to macro-optimization,
which focuses on choosing and
designing more optimal
algorithms for your problem set,
micro-optimization focuses on
optimizing the implementation
of the algorithms you are
already using. We will discuss
pros and cons of micro-
optimization, common Python
patterns which are surprisingly
suboptimal, new patterns to ease
optimization, and show how to
use the profiler and
disassembler to identify new
opportunities for optimization.

This talk will focus practical
examples on the Python 2.x
versions, but overall strategies
are useful for any version (or
any language, for that matter).  *Audience: Intermediate*

CARTOON 2: *Test Driven
Learning with Python Koans*
(Greg Malcom) - Bring a laptop
or sit with a partner and get
some hands on experience with
Python combined the chocolaty
goodness of Test Driven
Development!

The Python Koans are a set of
Unit Tests which will not pass
until you are sufficiently
enlightened. Enlightenment may
be achieved by filling in
missing values and occasionally
performing small feats, such as
writing some code to categorize
types of triangles.
These labs make use of the
Python Koans, a recent port of
the popular Ruby Koans
tutorial. They are fairly similar
but also feature content specific
to the Python language (such as
for learning about decorators
and generators). They are also
available for both Python 2.6
and Python 3.1, so this is a great
way to get caught up on newer
language features.
And don't worry if can only
attend for a short time, you can
work at your own pace!  *Audience: beginner/intermediate*

Saturday, 11 AM
---------------

ROUND ROOM: *Intro to Core
Involvement* (Dan Buch) -
You can help to advance
CPython into the future!
Whether you're able to help
with Documentation, bug triage,
or would even like to sling
some C, your efforts will be
greatly appreciated.  *Audience: beginner*


CARTOON 1: *Postgresql and
Python* (Brent Friedman) - An
overview of PostgreSQL and its
use with Python.  *Audience: beginner*


CARTOON 2: *Test Driven
Learning with Python Koans*
(continued)

Saturday, 1:30 PM
-----------------

ROUND ROOM: *Implementation of a Numerical
Simulation in Python* (Jeffrey B.
Armstrong) - The Python
programming language is well
suited for numerical
computation under a variety of
circumstances. Python offers
advantages over competing free
and commercial technologies,
including price, functionality,
and maintainability.

Specifically, the combination of
mature numerical libraries and
liberal licensing allow complex
simulations to be coded with
ease and to be made available to
nearly all interested parties.
NumPy/SciPy, database
access, networking, and
optimization techniques are
examined in detail with respect
to numerical computation. A
practical example involving an
aerothermal commercial
turbofan aircraft engine
simulation showcases these
advantages. An aircraft engine
is broken down into discrete
stages, including compressors,
turbines, and other flow-related
components. Commonalities
between components, such as
rotation and the presence of
inlet and exit conditions, map
cleanly to the object-oriented
nature of Python. Based on
simulation needs and hardware
availability, Python allows for
the parallel computation of
simulations without the expense
and complexity of commercial
parallelization packages.  *Audience: intermediate*

CARTOON 1: *Genetic
Programming in Python* (Eric Floehr) - 
Did you know you can create and evolve programs that find solutions to problems? This talk walks through how to use Genetic Programming (GP) as a tool to discover solutions to hard problems, when to use GP, how best to set up the GP environment, and how to interpret the results.  *Audience: beginner to intermediate*

CARTOON 2: *So Many Web
Frameworks, So Little Time*
(Gloria W. Jacobs) - A non-
biased, non-Django-centric
comparison of Python web
frameworks and related tools.
We'll be generating SVG maps
and playing with widgets,
discussing efficiency and
reviewing caching methods,
executing service based
examples, and taking an in-
depth look at the features and
limitations of many major
Python web frameworks and
tools. We'll see why there are so
many frameworks, and
instances when you may want to
choose one over another.  *Audience: intermediate*

Saturday, 2:30 PM
-----------------

ROUND ROOM: *Log Analysis
with Python* (Scott McCarty) -
Log analysis is something that
every programmer and systems
adminstrator must do
sometimes. This talk will be an
introduction to the concepts of
pattern recognition, artificial
ignorance, word counting,
stopword lists, and command
line graphing. It is based on a
pythonic implementation of
these techniques called petit and
will delve into several use cases
and show how using these
techniques can help you save
time when analyzing logs with
python.  *Audience: beginner*

CARTOON 1: *Getting to Know MongoDB Using Python and IronPython* (Sam Corder) - 
Is your RDBMS not coping with the load anymore and can't be scaled out any further? Are you designing the next big thing and know your RDBMS won't be able to handle it? Are you tired of shoe-horning a data model into where it doesn't belong? Are you just curious what this thing called MongoDB is? In this session you will explore a popular alternative to the RDBMS called Mongo from one who has battled with BSON to write the original .Net driver. You'll learn basics of schema design, document manipulation, several ways to get at your data, something odd called map/reduce and all from the comfort of Python and the slightly uncomfortable IronPython.  *Audience: any*

CARTOON 2: *So Many Web
Frameworks, So Little Time*
(continued)

Saturday, 3:30 PM
-----------------

ROUND ROOM: *Teach Me
Python Bugfixing* (Catherine
Devlin) - Python wants YOU to
help maintain and extend the
language we love so much... but
maybe you don't know how to
go about making your
contribution. Catherine doesn't
either. David Murray, an
experienced Python contributor,
will guide her - and you -
through the process, live and
unscripted. Come take part in
learner-controlled instruction.
No C programming required!  *Audience: Intermediate*

CARTOON 1: *GUI Tools* (James Bonanno) - 
There are several Graphical User Interface frameworks available for Python. In this talk, perpahs the two most popular, wxPython and PyQt, are examined. The talk will focus on major differences, tools, and a specific example done both in wxPython and PyQt, that is a non-trivial production grade example. *Audience: Intermediate/Advanced*

CARTOON 2: *So You Just Took
"Python 101" - What's Next?*
(Greg Lindstrom) -
In this class we will develop,
step-by-step and as a class, two
simple games, Hi/Low and
Hangman. We will start from
scratch and walk through each
step of each game discussing
decision making, loops ("for",
"while" and "if"), data
structures (tuple, list and
dictionary) and looking at
different ways to "get-r-done".
You should know a little about
Python but don't have to know
anything else about
programming (you should know
how to edit and run a Python
program on your Operating
System). Bring a computer with
Python installed if you want to
play along.  *Audience: beginner*

Saturday, 4:30 PM
-----------------

ROUND ROOM: *Python 101 for the .NET Developer* (Sarah Dutkiewicz) - 
The first part of the session will cover the basics of Python - its history, how its data structures compare to those we're familiar with in the primary .NET languages, its strong and weak points, who's using it, and why you as a developer - both generally speaking and as a .NET developer - should care about Python. The second part of the session will get into the demos - starting with some basic Python scripts and getting into IronPython scripts, if time allows. By the end of this session, you'll have an idea of what Python is, why you should know it as a developer and specifically as a .NET developer, and how to get setup and write a basic app in both Python and IronPython.  *Audience: Any*

CARTOON 1: *Wrangling the
Bits, Standardizing How Apps
Get Built* (Rick Harding) - As
we moved more work to Python
we had to figure out how to
start, share, and deploy projects
in a standard way. Virtualenv,
pip, and Git to the rescue.  *Audience: any*


CARTOON 2: *So You Just Took
"Python 101" - What's Next?*
(continued)

Saturday, 5:30 PM
-----------------

CARTOON 1+2: *Lightning
Talks* - A rapidfire series of five-
minute talks from all our
attendees.

Saturday, 7 PM
--------------

SUBWAY (1739 N. High Street): *Sprints*
- all are welcome!

Sunday, 12:30 PM
----------------

ROUND ROOM: *Building Your
Own Kind of Dictionary* (W.
Matthew Wilson) - My talk is based
on a project that seemed very
simple at first. I wanted an
object like the regular python
dictionary, but with a few small
tweaks:

 * values for some keys
   should be restricted to elements
   of a set
 * values for some keys
   should be restricted to instances
   of a type

For example, pretend I want a
dictionary called favorites, and I
want the value for the "color"
key to be any instance of my
Color class. Meanwhile, for the
"movie" key, I want to make
sure that the value belongs to
my set of movies.

In the talk, I'll walk through
how I used tests to validate my
different implementations until I
came up with a winner.

Unlike my talk last year on
metaclass tomfoolery, and the
year before that on fun with
decorators (and decorator
factories) I'm hoping to make
this talk straightforward and
friendly to beginning
programmers.

You'll see:

 * how I use tests to solve a
   real-world problem
 * a few little gotchas with the
   super keyword
 * a little about how python
   works under the hood.

*Audience: novice*


CARTOON 1+2: *Splunking with Python* (Benjamin W. Smith) - 
Getting dirty with the Splunk API and various other sysadmin tasks with Python. *Audience: Any*

Sunday, 1:30 PM
---------------

ROUND ROOM: *Processing
Large Datasets with Hadoop
and Python* (William McVey) -
This talk will explore how
Hadoop along with Python can
be used to process large
datasets. An overview of the
Apache Hadoop project will be
given. The map/reduce concept
will be introduced and some
methods of coding the data
processing routines in python
will be explored. The talk will
use real world examples to
illustrate how this approach can
be used to parallelize
computationally expensive
operations across multiple
cluster nodes effectively using
python.
The course will assume
familiarity with the Python
language during the demos, but
will not actually require a deep
knowledge of python to
understand the concepts
introduced.  *Audience: beginner*

CARTOON 1+2: *Controlling UNIX Processes Using Supervisor* (Calvin Hendryx-Parker) - 
Supervisor is a Python daemon that can control arbitrary processes in a UNIX-like environment. It features a client/server model of control that can easily be extended. This talk will cover the configuration and setup of Supervisor. It will also cover how to extend Supervisor and take advantage of its XML-RPC interface and ability to react to events that it generates. *Audience: intermediate*


Sunday, 2:30 PM
---------------


ROUND ROOM: *PyPy and Unladen-Swallow: Making Your Python Fast* (Alex Gaynor) -
Python has a reputation for being a bit slow, but it doesn't have to be that way. This talk will cover why Python is slow, and what two of the most exciting virtual machines are doing about it. *Audience: beginner/intermediate*

CARTOON 1+2: *Code with Style* (Clayton Parker) - 
Six Feet Up's senior developer Clayton Parker will lead you on a journey to become a Python Zen master. Your code should be as fashionable as it is functional. To quote the Zen of Python, "Beautiful is better than ugly". This talk will teach you about the Python style guide and why it is important. The talk will show you examples of well written Python and how to analyze your current code to make Guido proud. *Audience: beginner*

Sunday, 3:30 PM
---------------


ROUND ROOM: *Python and
Entrepreneurship* (Eric Floehr) -
One of the strengths of dynamic
languages is rapid development
and quick results. Python has
been used by a number of Ohio
small businesses, from
supporting back-office
operations to being the language
the company's products are built
on. This panel discussion will
talk about the opportunities and
challenges in using Python to
build a business on, as well as a
discussion on starting, running,
and growing a technology-based
business. *Audience: any*

CARTOON 1+2: *Lap Around IronPython* (Sarah Dutkiewicz) - 
It's not just C# and VB.NET that can be used in WinForms, WPF, Silverlight, and ASP.NET. You could also use IronPython! In this session, you will get a quick overview of IronPython and a look into using it with each of the following: WinForms, WPF, Silverlight, and ASP.NET.  *Audience: Intermediate; Basic knowledge of .NET helpful*

Sunday, 4:30 PM
---------------

CARTOON 1+2: *Making It Go Faster* (W. Matthew Wilson) - 
I'll use cProfile, pstats, and RunSnakeRun to find where code is getting bogged down in a real-world example. I'll measure the run-time cost with timeit, refactor, and measure it again.  

Finally, I'll talk about the limits of python optimization and show how to replace python code with C. *Audience: novice*

Sunday, 5:30 PM
---------------

CARTOON 1+2: *Lightning
Talks* - A rapidfire series of five-
minute talks from all our
attendees.

Sunday, 7 PM
------------

SUBWAY (1739 N. High Street): *Sprints*
- all are welcome!

Monday, 9 AM
------------

CREATIVE ARTS ROOM: *Sprints* - all
are welcome!

Monday, 7 PM
------------

SUBWAY (1739 N. High Street): *Sprints*
- all are welcome!

Tuesday, 9 AM
-------------

CREATIVE ARTS ROOM: *Sprints* - all
are welcome!

Tuesday, 7 PM
-------------

SUBWAY (1739 N. High Street): *Sprints*
- all are welcome!


.. raw:: pdf
 
   PageBreak
 
.. csv-table:: Saturday 
   :header: "",Round Room,Cartoon 1,Cartoon 2

   10:00,Project Management 101,Micro-optimization,Python Koans
   11:00,Core Involvement,Postgresql,(continued)
   12:00,Lunch,Lunch,Lunch
   1:30,Numerical Simulation,Genetic Programming,Web Frameworks
   2:30,Log Analysis,MongoDB (Python/IronPython),(continued)
   3:30,Bugfixing,GUI Tools,After Python 101
   4:30,Python 101 for .NET,App Building, (continued)
   5:30,,Lightning Talks

.. csv-table:: Sunday 
   :header: "",Round Room,Cartoon 1+2

   12:30,Your Own Dictionary,Splunk
   1:30,Hadoop,Supervisor
   2:30,PyPy and Unladen-Swallow,Code With Style
   3:30,Entrepreneurship,Lap Around IronPython
   4:30,,Faster
   5:30,,Lightning Talks

