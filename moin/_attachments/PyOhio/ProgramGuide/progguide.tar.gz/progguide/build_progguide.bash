#!/bin/bash
rst2pdf progguide.rst -o progguide.pdf -s sphinx.style,halfletter.style
